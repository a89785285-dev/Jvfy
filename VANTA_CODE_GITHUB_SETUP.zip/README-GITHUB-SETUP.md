# GitHub Actions setup — VANTA CODE

Copy the `.github` folder into the root of your VANTA CODE GitHub repository.

Expected layout:
```text
VANTA_CODE/
├── .github/
│   └── workflows/
│       └── build-apk.yml
├── main.py
├── buildozer.spec
├── requirements.txt
└── README.md
```

After pushing to `main` or `master`, open the repository's **Actions** tab.
You can also select **Build VANTA CODE APK** and press **Run workflow**.

When the workflow succeeds, open its run and download the
**VANTA-CODE-debug-apk** artifact.

This workflow builds a debug APK using Buildozer. It does not create an
Android Studio `app/` folder and it does not guarantee success until the
project builds successfully in GitHub Actions.
