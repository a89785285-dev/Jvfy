package com.vanta.code

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.mozilla.javascript.Context
import org.mozilla.javascript.Scriptable

private val Back = Color(0xFF090A12)
private val Surface = Color(0xFF141827)
private val Surface2 = Color(0xFF1C2234)
private val Violet = Color(0xFF9A75FF)
private val Aqua = Color(0xFF57D9D0)
private val Green = Color(0xFF6EE7B7)
private val TextMain = Color(0xFFF4F3FA)
private val TextDim = Color(0xFF929BB2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VantaStudio() }
    }
}

@Composable
private fun VantaStudio() {
    var source by remember { mutableStateOf("// Welcome to VANTA CODE\nconst name = 'VANTA';\nconsole.log('Hello from ' + name);\nconsole.log('Your coding studio is ready.');") }
    var output by remember { mutableStateOf("Ready. Press Run to execute JavaScript.") }
    var fileName by remember { mutableStateOf("main.js") }
    var language by remember { mutableStateOf("JavaScript") }
    var tab by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var showResult by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { source = it.readText() }; fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "project.txt"; output = "Opened $fileName" }.onFailure { output = "Open error: ${it.message}" }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(source) }; output = "File saved successfully." }.onFailure { output = "Save error: ${it.message}" }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Back, surface = Surface, onSurface = TextMain)) {
        Column(Modifier.fillMaxSize().background(Back)) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF0E1220)).statusBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Violet.copy(alpha = .18f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text("V", color = Violet, fontSize = 27.sp, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(11.dp)); Column { Text("VANTA", color = TextMain, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 2.sp); Text("CODE STUDIO", color = TextDim, fontSize = 9.sp, letterSpacing = 2.sp) }
                Spacer(Modifier.weight(1f))
                if (showResult) IconButton(onClick = { showResult = false }) { Icon(Icons.Default.ArrowBack, "Back", tint = TextDim) }
            }
            when (tab) {
                0 -> {
                    if (showResult) {
                        Column(Modifier.fillMaxSize().padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("EXECUTION", color = TextDim, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                    Text("Result", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                }
                                Surface(color = Color(0xFF15382F), shape = RoundedCornerShape(20.dp)) {
                                    Text(if (output.startsWith("Execution error")) " ERROR " else " COMPLETED ", color = Green, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
                                }
                            }
                            Spacer(Modifier.height(18.dp))
                            Row(Modifier.fillMaxWidth().background(Surface2, RoundedCornerShape(13.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Terminal, null, tint = Aqua)
                                Spacer(Modifier.width(9.dp))
                                Text("CONSOLE OUTPUT", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Spacer(Modifier.weight(1f))
                                Text(fileName, color = TextDim, fontSize = 10.sp)
                            }
                            Column(Modifier.fillMaxWidth().weight(1f).padding(top = 8.dp).background(Surface, RoundedCornerShape(14.dp)).padding(16.dp)) {
                                Text(output, color = if (output.startsWith("Execution error")) Color(0xFFFF8585) else Color(0xFFBFEBD8), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 21.sp)
                            }
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = { showResult = false }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                                Icon(Icons.Default.Code, null); Spacer(Modifier.width(8.dp)); Text("Back to editor")
                            }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("WORKSPACE", color = TextDim, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold); Text("My first project", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
                            Text(language.uppercase(), color = Aqua, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).background(Surface2, RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).background(Aqua, RoundedCornerShape(50))); Spacer(Modifier.width(9.dp)); Text(fileName, color = TextMain, fontFamily = FontFamily.Monospace, fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text("● LOCAL", color = TextDim, fontSize = 9.sp)
                        }
                        // Editor gets the majority of the available screen; actions live in a vertical side rail.
                        Row(Modifier.weight(1f).padding(horizontal = 16.dp).background(Surface)) {
                            Column(Modifier.width(42.dp).fillMaxHeight().background(Color(0xFF101421)).padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                repeat((source.count { it == '\n' } + 1).coerceAtMost(300)) { Text("${it + 1}", color = TextDim.copy(alpha = .65f), fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 20.sp) }
                            }
                            BasicTextField(value = source, onValueChange = { source = it }, modifier = Modifier.weight(1f).fillMaxHeight().padding(12.dp), textStyle = TextStyle(color = Color(0xFFDDE1F2), fontFamily = FontFamily.Monospace, fontSize = 14.sp, lineHeight = 23.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Violet))
                            Column(
                                Modifier.width(46.dp).fillMaxHeight().background(Color(0xFF101421)).padding(vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                SideTool(Icons.Default.PlayArrow, "Run", Violet) {
                                    output = if (language == "JavaScript") executeJs(source)
                                    else "$language editor is available; its runtime/compiler is not included in this build."
                                    showResult = true
                                }
                                SideTool(Icons.Default.FolderOpen, "Open", Aqua) { opener.launch(arrayOf("text/*")) }
                                SideTool(Icons.Default.Save, "Save", Aqua) { saver.launch(fileName) }
                                SideTool(Icons.Default.Add, "Insert", Aqua) { source += "\\nconsole.log('');" }
                                SideTool(Icons.Default.DeleteOutline, "Clear", Color(0xFFFF8585)) { source = "" }
                                HorizontalDivider(color = TextDim.copy(alpha = .2f), modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
                                SideTool(Icons.Default.Translate, "Lang", Aqua) { menu = true }
                                SideTool(Icons.Default.Folder, "Files", Aqua) { tab = 1 }
                                SideTool(Icons.Default.Settings, "Setup", Aqua) { tab = 2 }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    listOf("JavaScript", "HTML", "CSS", "Python", "Java", "Kotlin", "C++", "PHP", "Dart").forEach { lang ->
                                        DropdownMenuItem(text = { Text(lang, fontSize = 12.sp) }, onClick = {
                                            language = lang
                                            fileName = when(lang) {
                                                "JavaScript" -> "main.js"; "HTML" -> "index.html"; "CSS" -> "style.css"
                                                "Python" -> "main.py"; "Java" -> "Main.java"; "Kotlin" -> "Main.kt"
                                                "C++" -> "main.cpp"; "PHP" -> "index.php"; else -> "main.dart"
                                            }
                                            source = when(lang) {
                                                "JavaScript" -> "console.log('Hello VANTA');"
                                                "HTML" -> "<!doctype html>\\n<html>\\n<body><h1>Hello VANTA</h1></body>\\n</html>"
                                                "CSS" -> "body {\\n  background: #090a12;\\n  color: white;\\n}"
                                                "Python" -> "print('Hello VANTA')"
                                                "Java" -> "public class Main {\\n  public static void main(String[] args) {\\n    System.out.println(\\\"Hello VANTA\\\");\\n  }\\n}"
                                                "Kotlin" -> "fun main() {\\n  println(\\\"Hello VANTA\\\")\\n}"
                                                "C++" -> "#include <iostream>\\nint main() { std::cout << \\\"Hello VANTA\\\"; }"
                                                "PHP" -> "<?php echo 'Hello VANTA'; ?>"
                                                else -> "void main() { print('Hello VANTA'); }"
                                            }
                                            menu = false
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> Column(Modifier.fillMaxSize().padding(20.dp)) { TextButton(onClick = { tab = 0 }) { Icon(Icons.Default.ArrowBack, null); Text(" Editor") }; Text("Projects", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Your coding workspace", color = TextDim); Spacer(Modifier.height(22.dp)); Button(onClick = { source = "// New project\nconsole.log('Hello VANTA');"; fileName = "main.js"; language = "JavaScript"; tab = 0 }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Icon(Icons.Default.Add, null); Text("  New JavaScript project") }; Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = { opener.launch(arrayOf("text/*")) }) { Icon(Icons.Default.FolderOpen, null); Text("  Open a file from device") } }
                else -> Column(Modifier.fillMaxSize().padding(20.dp)) { TextButton(onClick = { tab = 0 }) { Icon(Icons.Default.ArrowBack, null); Text(" Editor") }; Text("Settings", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); listOf("Theme" to "VANTA Dark Studio", "JavaScript engine" to "Rhino runtime", "Other languages" to "Editor templates only", "Version" to "1.0.0").forEach { (a,b) -> Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Surface, RoundedCornerShape(12.dp)).padding(15.dp)) { Text(a, color = TextMain, fontWeight = FontWeight.SemiBold); Text(b, color = TextDim, fontSize = 12.sp) } } }
            }

        }
    }
}


@Composable
private fun SideTool(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        Modifier.width(44.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(17.dp))
        Text(label, color = TextDim, fontSize = 8.sp, lineHeight = 10.sp, maxLines = 1)
    }
}

private fun executeJs(code: String): String = try {
    val cx = Context.enter(); cx.optimizationLevel = -1; cx.languageVersion = Context.VERSION_ES6
    try {
        val scope: Scriptable = cx.initStandardObjects(); val logs = mutableListOf<String>()
        val console = cx.newObject(scope)
        val fn = object : org.mozilla.javascript.BaseFunction() {
            override fun call(cx: Context, scope: Scriptable, thisObj: Scriptable, args: Array<out Any>): Any { logs += args.joinToString(" ") { Context.toString(it) }; return org.mozilla.javascript.Undefined.instance }
        }
        console.put("log", console, fn); console.put("warn", console, fn); console.put("error", console, fn); scope.put("console", scope, console)
        cx.evaluateString(scope, code, "VANTA", 1, null)
        if (logs.isEmpty()) "Executed successfully. No console output." else logs.joinToString("\n")
    } finally { Context.exit() }
} catch (e: Throwable) { "Execution error: ${e.message ?: e.javaClass.simpleName}" }
