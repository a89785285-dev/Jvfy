# VANTA CODE Android

A fresh Android Studio project for VANTA CODE, built with Kotlin and Jetpack Compose.

## Build locally
- Android Studio with JDK 17
- Open this folder as a project and allow Gradle sync.
- Run the `app` configuration.

## Build with GitHub Actions
Push the project files to the repository's `main` or `master` branch, or run **VANTA APK Builder** manually from Actions. The debug APK is uploaded as an artifact named `VANTA-CODE-APK`.

## Included in this starter
- Dark VANTA interface with neon-green accents
- Compact vertical action toolbar
- Code editor with line-number gutter
- JavaScript execution via Rhino
- Open and Save using Android document picker
- Projects and Settings screens

Other language entries are editor-only in this initial version; they do not have execution engines yet.
