package com.vanta.code.ui

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.mozilla.javascript.Context as RhinoContext
import org.mozilla.javascript.ClassShutter
import java.io.BufferedReader
import java.io.InputStreamReader

private val Bg = Color(0xFF080B09)
private val Panel = Color(0xFF111713)
private val Panel2 = Color(0xFF172019)
private val Neon = Color(0xFFB6FF3B)
private val Muted = Color(0xFF91A095)

private enum class Page { EDITOR, PROJECTS, SETTINGS }

@Composable
fun VantaApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf(Page.EDITOR) }
    var code by remember {
        mutableStateOf(
            """// Welcome to VANTA CODE
// JavaScript runtime: Rhino

const project = "VANTA";
const version = "1.0.0";

print("Welcome to " + project);
print("Version: " + version);
"""
        )
    }
    var output by remember { mutableStateOf("Ready. Select RUN to execute JavaScript.") }
    var language by remember { mutableStateOf("JavaScript") }
    var fileName by remember { mutableStateOf("main.js") }
    var showLanguageMenu by remember { mutableStateOf(false) }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    code = BufferedReader(InputStreamReader(stream)).readText()
                }
                fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "opened-file"
                output = "Opened: $fileName"
            }.onFailure { output = "Open failed: ${it.message}" }
        }
    }
    val saveFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(code) }
                output = "Saved successfully."
            }.onFailure { output = "Save failed: ${it.message}" }
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(fileName)
        HorizontalDivider(color = Color(0xFF263329))
        Row(Modifier.weight(1f).fillMaxWidth()) {
            SideBar(
                selected = page,
                onSelect = { page = it },
                onRun = {
                    if (language != "JavaScript") {
                        output = "$language editor is ready. Its runtime is not included in this version."
                    } else {
                        output = executeJavaScript(code)
                    }
                },
                onOpen = { openFile.launch(arrayOf("*/*")) },
                onSave = { saveFile.launch(fileName.ifBlank { "main.js" }) },
                onClear = { code = ""; output = "Editor cleared." }
            )
            Column(Modifier.weight(1f).fillMaxHeight()) {
                when (page) {
                    Page.EDITOR -> {
                        EditorHeader(
                            fileName = fileName,
                            language = language,
                            onLanguage = { showLanguageMenu = true }
                        )
                        Box(Modifier.weight(1f).fillMaxWidth().padding(10.dp)) {
                            CodeEditor(code = code, onCodeChange = { code = it })
                        }
                        TerminalPanel(output = output, onClear = { output = "Terminal cleared." })
                    }
                    Page.PROJECTS -> ProjectsPage(
                        onNew = {
                            code = "// New VANTA project\nprint(\"Hello VANTA\");\n"
                            fileName = "untitled.js"
                            page = Page.EDITOR
                            output = "New editor session created."
                        },
                        onOpen = { page = Page.EDITOR }
                    )
                    Page.SETTINGS -> SettingsPage()
                }
            }
        }
        if (showLanguageMenu) {
            AlertDialog(
                onDismissRequest = { showLanguageMenu = false },
                title = { Text("Select language") },
                text = {
                    Column {
                        listOf("JavaScript", "Python", "Java", "Kotlin", "C++", "PHP", "Dart").forEach {
                            TextButton(onClick = {
                                language = it
                                fileName = when (it) {
                                    "JavaScript" -> "main.js"
                                    "Python" -> "main.py"
                                    "Java" -> "Main.java"
                                    "Kotlin" -> "Main.kt"
                                    "C++" -> "main.cpp"
                                    "PHP" -> "main.php"
                                    else -> "main.dart"
                                }
                                showLanguageMenu = false
                            }) { Text(it, color = if (language == it) Neon else Color.White) }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showLanguageMenu = false }) { Text("DONE", color = Neon) }
                },
                containerColor = Panel
            )
        }
    }
}

@Composable
private fun TopBar(fileName: String) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D120E)).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(34.dp).background(Neon, RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("V", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 22.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("VANTA CODE", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 15.sp)
            Text("DEVELOPMENT STUDIO", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
        }
        Text("●", color = Neon, fontSize = 10.sp)
        Spacer(Modifier.width(6.dp))
        Text("LOCAL", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun SideBar(
    selected: Page,
    onSelect: (Page) -> Unit,
    onRun: () -> Unit,
    onOpen: () -> Unit,
    onSave: () -> Unit,
    onClear: () -> Unit
) {
    Column(
        Modifier.width(58.dp).fillMaxHeight().background(Color(0xFF0D120E))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        SideAction(Icons.Default.PlayArrow, "Run", true, onRun)
        SideAction(Icons.Default.FolderOpen, "Open", false, onOpen)
        SideAction(Icons.Default.Save, "Save", false, onSave)
        SideAction(Icons.Default.Add, "Insert", false) { onRun() }
        SideAction(Icons.Default.DeleteOutline, "Clear", false, onClear)
        HorizontalDivider(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = Color(0xFF29352C))
        SideAction(Icons.Default.Code, "Editor", selected == Page.EDITOR) { onSelect(Page.EDITOR) }
        SideAction(Icons.Default.Folder, "Projects", selected == Page.PROJECTS) { onSelect(Page.PROJECTS) }
        SideAction(Icons.Default.Settings, "Settings", selected == Page.SETTINGS) { onSelect(Page.SETTINGS) }
    }
}

@Composable
private fun SideAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(42.dp).background(
                if (active) Color(0xFF26351D) else Color.Transparent,
                RoundedCornerShape(12.dp)
            )
        ) {
            Icon(icon, contentDescription = label, tint = if (active) Neon else Muted, modifier = Modifier.size(21.dp))
        }
        Text(label, color = if (active) Neon else Muted, fontSize = 8.sp)
    }
}

@Composable
private fun EditorHeader(fileName: String, language: String, onLanguage: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Description, null, tint = Neon, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(7.dp))
        Text(fileName, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onLanguage, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
            Text(language.uppercase(), color = Neon, fontSize = 10.sp)
            Icon(Icons.Default.ArrowDropDown, null, tint = Neon)
        }
    }
}

@Composable
private fun CodeEditor(code: String, onCodeChange: (String) -> Unit) {
    Row(
        Modifier.fillMaxSize().background(Color(0xFF0B100C), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF263329), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        val lines = remember(code) { code.count { it == '\n' } + 1 }
        Column(Modifier.width(27.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.End) {
            repeat(lines) { index ->
                Text(
                    "${index + 1}",
                    color = Color(0xFF627268),
                    fontSize = 12.sp,
                    lineHeight = 20.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        Spacer(Modifier.width(9.dp))
        BasicTextField(
            value = code,
            onValueChange = onCodeChange,
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            textStyle = androidx.compose.ui.text.TextStyle(
                color = Color(0xFFD7E7D9),
                fontSize = 13.sp,
                lineHeight = 20.sp,
                fontFamily = FontFamily.Monospace
            ),
            cursorBrush = androidx.compose.ui.graphics.SolidColor(Neon)
        )
    }
}

@Composable
private fun TerminalPanel(output: String, onClear: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().heightIn(min = 112.dp, max = 170.dp)
            .background(Color(0xFF0D120E)).padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Terminal, null, tint = Neon, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(7.dp))
            Text("TERMINAL", color = Color.White, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onClear, contentPadding = PaddingValues(4.dp)) {
                Text("CLEAR", color = Muted, fontSize = 9.sp)
            }
        }
        HorizontalDivider(color = Color(0xFF263329))
        Text(
            output,
            color = Color(0xFFB8D1BC),
            fontSize = 11.sp,
            lineHeight = 16.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 7.dp).verticalScroll(rememberScrollState())
        )
    }
}

@Composable
private fun ProjectsPage(onNew: () -> Unit, onOpen: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("PROJECTS", color = Neon, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Your workspace", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Create a workspace or return to the editor.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Code, null, tint = Neon, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("main.js", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("JavaScript • Local workspace", color = Muted, fontSize = 10.sp)
                }
                TextButton(onClick = onOpen) { Text("OPEN", color = Neon) }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("NEW PROJECT")
        }
    }
}

@Composable
private fun SettingsPage() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("SETTINGS", color = Neon, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("VANTA CODE", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Version 1.0.0 • Android", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        SettingRow("Theme", "Dark / Neon Green")
        SettingRow("Editor font", "Monospace")
        SettingRow("JavaScript engine", "Rhino 1.7.15")
        SettingRow("Other languages", "Editor support only")
        Spacer(Modifier.height(14.dp))
        Text(
            "Python, Java, Kotlin, C++, PHP and Dart can be edited, but their execution engines are not bundled in this starter build.",
            color = Muted,
            fontSize = 11.sp,
            lineHeight = 17.sp
        )
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(title, color = Color.White, fontSize = 13.sp)
        Text(value, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color = Color(0xFF263329))
    }
}

private fun executeJavaScript(source: String): String {
    return try {
        val rhino = RhinoContext.enter()
        try {
            rhino.optimizationLevel = -1
            rhino.classShutter = ClassShutter { _ -> false }
            val scope = rhino.initStandardObjects()
            val logs = StringBuilder()
            scope.put("print", scope, org.mozilla.javascript.BaseFunction().apply {
                override fun call(
                    cx: RhinoContext,
                    scope: org.mozilla.javascript.Scriptable,
                    thisObj: org.mozilla.javascript.Scriptable,
                    args: Array<out Any>
                ): Any {
                    logs.append(args.joinToString(" ") { RhinoContext.toString(it) }).append('\n')
                    return org.mozilla.javascript.Undefined.instance
                }
            })
            val result = rhino.evaluateString(scope, source, "VANTA", 1, null)
            if (result != org.mozilla.javascript.Undefined.instance) {
                val value = RhinoContext.toString(result)
                if (value.isNotBlank() && value != "undefined") logs.append(value).append('\n')
            }
            logs.toString().ifBlank { "Execution completed successfully." }
        } finally {
            RhinoContext.exit()
        }
    } catch (e: Exception) {
        "Runtime error: ${e.message ?: e.javaClass.simpleName}"
    }
}
