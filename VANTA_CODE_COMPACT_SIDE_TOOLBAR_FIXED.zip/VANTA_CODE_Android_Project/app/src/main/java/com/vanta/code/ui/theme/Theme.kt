package com.vanta.code.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VantaColors = darkColorScheme(
    primary = Color(0xFFB6FF3B),
    onPrimary = Color(0xFF172000),
    secondary = Color(0xFF8BEA35),
    background = Color(0xFF080B09),
    surface = Color(0xFF111713),
    surfaceVariant = Color(0xFF1A241D),
    onBackground = Color(0xFFE7F0E9),
    onSurface = Color(0xFFE7F0E9),
    onSurfaceVariant = Color(0xFFA4B3A7),
    outline = Color(0xFF344238)
)

@Composable
fun VantaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VantaColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
