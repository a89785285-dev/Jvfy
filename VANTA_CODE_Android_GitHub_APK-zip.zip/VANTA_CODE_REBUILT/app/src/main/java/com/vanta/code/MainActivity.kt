package com.vanta.code

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.mozilla.javascript.Context
import org.mozilla.javascript.Scriptable

private val Back = Color(0xFF090A12)
private val Surface = Color(0xFF141827)
private val Surface2 = Color(0xFF1C2234)
private val Violet = Color(0xFF9A75FF)
private val Aqua = Color(0xFF57D9D0)
private val TextMain = Color(0xFFF4F3FA)
private val TextDim = Color(0xFF929BB2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VantaStudio() }
    }
}

@Composable
private fun VantaStudio() {
    var source by remember { mutableStateOf("// Welcome to VANTA CODE\nconst name = 'VANTA';\nconsole.log('Hello from ' + name);\nconsole.log('Your coding studio is ready.');") }
    var output by remember { mutableStateOf("Ready. Press Run to execute JavaScript.") }
    var fileName by remember { mutableStateOf("main.js") }
    var language by remember { mutableStateOf("JavaScript") }
    var tab by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { source = it.readText() }; fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "project.txt"; output = "Opened $fileName" }.onFailure { output = "Open error: ${it.message}" }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(source) }; output = "File saved successfully." }.onFailure { output = "Save error: ${it.message}" }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Back, surface = Surface, onSurface = TextMain)) {
        Column(Modifier.fillMaxSize().background(Back)) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF0E1220)).statusBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Violet.copy(alpha = .18f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text("V", color = Violet, fontSize = 27.sp, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(11.dp)); Column { Text("VANTA", color = TextMain, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 2.sp); Text("CODE STUDIO", color = TextDim, fontSize = 9.sp, letterSpacing = 2.sp) }
                Spacer(Modifier.weight(1f)); IconButton(onClick = { tab = 1 }) { Icon(Icons.Default.FolderOpen, null, tint = TextDim) }; Box { IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null, tint = TextDim) }; DropdownMenu(menu, { menu = false }) { DropdownMenuItem(text = { Text("Open file") }, onClick = { menu = false; opener.launch(arrayOf("text/*", "application/json")) }); DropdownMenuItem(text = { Text("Save as") }, onClick = { menu = false; saver.launch(fileName) }) } }
            }
            when (tab) {
                0 -> {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("WORKSPACE", color = TextDim, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold); Text("My first project", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
                        Box { OutlinedButton(onClick = { menu = true }, shape = RoundedCornerShape(12.dp)) { Text(language, color = Aqua, fontSize = 12.sp); Icon(Icons.Default.ExpandMore, null, tint = TextDim) } }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).background(Surface2, RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Aqua, RoundedCornerShape(50))); Spacer(Modifier.width(9.dp)); Text(fileName, color = TextMain, fontFamily = FontFamily.Monospace, fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text("● LOCAL", color = TextDim, fontSize = 9.sp)
                    }
                    Row(Modifier.weight(1f).padding(horizontal = 16.dp).background(Surface)) {
                        Column(Modifier.width(35.dp).fillMaxHeight().background(Color(0xFF101421)).padding(top = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) { repeat((source.count { it == '\n' } + 1).coerceAtMost(200)) { Text("${it + 1}", color = TextDim.copy(alpha = .65f), fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 21.sp) } }
                        BasicTextField(value = source, onValueChange = { source = it }, modifier = Modifier.fillMaxSize().padding(12.dp), textStyle = TextStyle(color = Color(0xFFDDE1F2), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 21.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Violet))
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).background(Surface2).padding(5.dp), horizontalArrangement = Arrangement.SpaceEvenly) { listOf("{ }", "( )", "[ ]", ";", "=", "=>").forEach { TextButton(onClick = { source += it }) { Text(it, color = Aqua, fontFamily = FontFamily.Monospace) } } }
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp).background(Surface, RoundedCornerShape(14.dp)).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Terminal, null, tint = Aqua, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("CONSOLE", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp); Spacer(Modifier.weight(1f)); TextButton(onClick = { output = "Console cleared." }) { Text("CLEAR", color = TextDim, fontSize = 9.sp) } }
                        Text(output, color = Color(0xFFBFC8DC), fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 17.sp, maxLines = 4)
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { opener.launch(arrayOf("text/*")) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text("Open") }
                        OutlinedButton(onClick = { saver.launch(fileName) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(4.dp)); Text("Save") }
                        Button(onClick = { output = if (language == "JavaScript") executeJs(source) else "$language editor is available; its runtime/compiler is not included in this build." }, modifier = Modifier.weight(1.2f), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Icon(Icons.Default.PlayArrow, null); Text("Run", fontWeight = FontWeight.Bold) }
                    }
                }
                1 -> Column(Modifier.fillMaxSize().padding(20.dp)) { Text("Projects", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Your coding workspace", color = TextDim); Spacer(Modifier.height(22.dp)); Button(onClick = { source = "// New project\nconsole.log('Hello VANTA');"; fileName = "main.js"; language = "JavaScript"; tab = 0 }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Icon(Icons.Default.Add, null); Text("  New JavaScript project") }; Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = { opener.launch(arrayOf("text/*")) }) { Icon(Icons.Default.FolderOpen, null); Text("  Open a file from device") } }
                else -> Column(Modifier.fillMaxSize().padding(20.dp)) { Text("Settings", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); listOf("Theme" to "VANTA Dark Studio", "JavaScript engine" to "Rhino runtime", "Other languages" to "Editor templates only", "Version" to "1.0.0").forEach { (a,b) -> Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Surface, RoundedCornerShape(12.dp)).padding(15.dp)) { Text(a, color = TextMain, fontWeight = FontWeight.SemiBold); Text(b, color = TextDim, fontSize = 12.sp) } } }
            }
            NavigationBar(containerColor = Color(0xFF0E1220)) {
                listOf("Editor", "Projects", "Settings").forEachIndexed { index, label -> NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = { Icon(when(index) { 0 -> Icons.Default.Code; 1 -> Icons.Default.Folder; else -> Icons.Default.Settings }, null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet, indicatorColor = Violet.copy(alpha = .15f), unselectedIconColor = TextDim, unselectedTextColor = TextDim)) }
            }
        }
    }
}

private fun executeJs(code: String): String = try {
    val cx = Context.enter(); cx.optimizationLevel = -1; cx.languageVersion = Context.VERSION_ES6
    try {
        val scope: Scriptable = cx.initStandardObjects(); val logs = mutableListOf<String>()
        val console = cx.newObject(scope)
        val fn = object : org.mozilla.javascript.BaseFunction() {
            override fun call(cx: Context, scope: Scriptable, thisObj: Scriptable, args: Array<out Any>): Any { logs += args.joinToString(" ") { Context.toString(it) }; return org.mozilla.javascript.Undefined.instance }
        }
        console.put("log", console, fn); console.put("warn", console, fn); console.put("error", console, fn); scope.put("console", scope, console)
        cx.evaluateString(scope, code, "VANTA", 1, null)
        if (logs.isEmpty()) "Executed successfully. No console output." else logs.joinToString("\n")
    } finally { Context.exit() }
} catch (e: Throwable) { "Execution error: ${e.message ?: e.javaClass.simpleName}" }
