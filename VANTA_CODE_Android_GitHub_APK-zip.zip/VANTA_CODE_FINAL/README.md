# VANTA CODE 1.0 — Android IDE

A native Android Studio project built with Kotlin and Jetpack Compose.

## Included and implemented
- Dark VANTA-themed coding workspace.
- Editable source area with line numbers.
- Language/template selector for JavaScript, HTML, CSS, Python, Java, Kotlin, C, C++, PHP and Dart.
- Local project file saving and opening in the app's private storage.
- **Real local JavaScript execution** using the embedded Rhino engine. Supports `print(...)` and `console.log/warn/error(...)` output.
- HTML and CSS preview using Android WebView.
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Runtime support — important
- JavaScript: executable locally with Rhino. This is JavaScript, not Node.js; Node APIs such as `require`, npm and filesystem modules are not provided.
- HTML/CSS: previewed locally in WebView.
- Python, Java, Kotlin, C, C++, PHP and Dart: editor/templates and file saving are included, but their execution toolchains are **not** bundled in this build. The app reports this rather than pretending to run them.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this ZIP (not the ZIP file itself).
2. Open the repository's **Actions** tab.
3. Select **Build VANTA CODE APK** and press **Run workflow**, or push to `main`.
4. When the run succeeds, open it and download the `VANTA-CODE-1.0-debug-apk` artifact.

## Build locally
Open the folder in Android Studio (JDK 17, Android SDK 35, Gradle 8.9), then run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
This source package is a debug-build project, not a signed Play Store release. A successful APK build should be confirmed by the GitHub Actions result before treating the APK as tested on a device.
