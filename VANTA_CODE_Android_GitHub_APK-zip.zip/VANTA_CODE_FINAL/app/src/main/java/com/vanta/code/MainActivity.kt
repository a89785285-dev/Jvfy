package com.vanta.code

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.mozilla.javascript.BaseFunction
import org.mozilla.javascript.Context as JsContext
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject
import java.io.File

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF111522)
private val Panel2 = Color(0xFF191F30)
private val Accent = Color(0xFF9D7BFF)
private val MainText = Color(0xFFE9EAF2)
private val Muted = Color(0xFF8993AA)

private data class Lang(val name: String, val ext: String, val template: String)
private val languages = listOf(
    Lang("JavaScript", "js", "// VANTA CODE 1.0\nconsole.log('Hello, VANTA!');\nprint(2 + 3);\n"),
    Lang("HTML", "html", "<!doctype html>\n<html>\n<head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>VANTA</title></head>\n<body style=\"background:#080a12;color:white;font-family:sans-serif;padding:24px\">\n  <h1>Hello, VANTA!</h1>\n  <p>Your HTML preview works.</p>\n</body>\n</html>\n"),
    Lang("CSS", "css", "body {\n  background: #080a12;\n  color: white;\n  font-family: sans-serif;\n}\n"),
    Lang("Python", "py", "# Python sample\nprint('Hello, VANTA!')\n"),
    Lang("Java", "java", "public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, VANTA!\");\n    }\n}\n"),
    Lang("Kotlin", "kt", "fun main() {\n    println(\"Hello, VANTA!\")\n}\n"),
    Lang("C", "c", "#include <stdio.h>\nint main(void) {\n    printf(\"Hello, VANTA!\\n\");\n    return 0;\n}\n"),
    Lang("C++", "cpp", "#include <iostream>\nint main() {\n    std::cout << \"Hello, VANTA!\" << std::endl;\n    return 0;\n}\n"),
    Lang("PHP", "php", "<?php\necho 'Hello, VANTA!';\n"),
    Lang("Dart", "dart", "void main() {\n  print('Hello, VANTA!');\n}\n")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VantaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VantaApp() {
    val context = LocalContext.current
    val projectDir = remember { File(context.filesDir, "projects/MyProject").apply { mkdirs() } }
    var language by remember { mutableStateOf(languages.first()) }
    var source by remember { mutableStateOf(language.template) }
    var fileName by remember { mutableStateOf("main.js") }
    var console by remember { mutableStateOf("VANTA CODE 1.0 ready.\\nJavaScript engine: Rhino") }
    var showConsole by remember { mutableStateOf(true) }
    var showFiles by remember { mutableStateOf(false) }
    var showPreview by remember { mutableStateOf(false) }
    var langMenu by remember { mutableStateOf(false) }
    var fileMenu by remember { mutableStateOf(false) }
    var previewHtml by remember { mutableStateOf("") }
    var revision by remember { mutableIntStateOf(0) }

    fun saveCurrent() {
        val safeName = fileName.substringAfterLast('/').ifBlank { "main.${language.ext}" }
        File(projectDir, safeName).writeText(source)
        fileName = safeName
        revision++
        Toast.makeText(context, "Saved: $safeName", Toast.LENGTH_SHORT).show()
    }

    fun runCurrent() {
        when (language.ext) {
            "js" -> {
                console = runJavaScript(source)
                showConsole = true
                showPreview = false
            }
            "html" -> {
                previewHtml = source
                showPreview = true
                showConsole = false
            }
            "css" -> {
                previewHtml = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>$source</style></head><body><h2>VANTA CSS Preview</h2><p>Edit CSS and press Run to refresh.</p></body></html>"
                showPreview = true
                showConsole = false
            }
            else -> {
                console = "${language.name} execution is not included in this build yet.\\nYour code can still be edited and saved.\\nAvailable runner: JavaScript. HTML/CSS: WebView preview."
                showConsole = true
                showPreview = false
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel, onSurface = MainText)) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("VANTA CODE", fontWeight = FontWeight.Black, letterSpacing = 1.7.sp, color = MainText)
                            Text("MOBILE IDE  •  VERSION 1.0", color = Muted, fontSize = 9.sp, letterSpacing = 1.1.sp)
                        }
                    },
                    navigationIcon = { Icon(Icons.Default.Terminal, null, tint = Accent, modifier = Modifier.padding(start = 14.dp).size(25.dp)) },
                    actions = {
                        IconButton(onClick = { saveCurrent() }) { Icon(Icons.Default.Save, "Save", tint = Accent) }
                        IconButton(onClick = { showFiles = !showFiles; showPreview = false }) { Icon(Icons.Default.FolderOpen, "Files", tint = MainText) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("MyProject", color = MainText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Workspace / $fileName", color = Muted, fontSize = 10.sp)
                    }
                    Box {
                        OutlinedButton(onClick = { langMenu = true }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                            Text(language.name, fontSize = 11.sp); Icon(Icons.Default.ArrowDropDown, null)
                        }
                        DropdownMenu(expanded = langMenu, onDismissRequest = { langMenu = false }) {
                            languages.forEach { item -> DropdownMenuItem(text = { Text(item.name) }, onClick = {
                                language = item; source = item.template; fileName = "main.${item.ext}"; langMenu = false; showFiles = false; showPreview = false
                            }) }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 9.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ActionChip("New", Icons.Default.NoteAdd) { source = language.template; fileName = "main.${language.ext}"; showFiles = false }
                    ActionChip("Save", Icons.Default.Save) { saveCurrent() }
                    ActionChip("Run", Icons.Default.PlayArrow, true) { saveCurrent(); runCurrent() }
                    ActionChip("Output", Icons.Default.Terminal) { showConsole = true; showPreview = false; showFiles = false }
                    ActionChip("Files", Icons.Default.Folder) { showFiles = true; showPreview = false }
                }
                when {
                    showFiles -> {
                        Card(Modifier.fillMaxWidth().weight(1f).padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
                            Column(Modifier.fillMaxSize().padding(14.dp)) {
                                Text("PROJECT FILES", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("Stored locally on this device", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp, bottom = 10.dp))
                                val files = remember(revision) { projectDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList() }
                                if (files.isEmpty()) Text("No saved files yet. Tap Save to create your first file.", color = Muted, fontSize = 12.sp)
                                files.forEach { file ->
                                    Surface(onClick = {
                                        val found = languages.firstOrNull { it.ext == file.extension }
                                        if (found != null) language = found
                                        fileName = file.name
                                        source = runCatching { file.readText() }.getOrDefault("")
                                        showFiles = false
                                    }, color = Panel2, shape = RoundedCornerShape(9.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Description, null, tint = Accent)
                                            Text(file.name, color = MainText, modifier = Modifier.padding(start = 9.dp).weight(1f), fontSize = 12.sp)
                                            Text("${file.length()} B", color = Muted, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    showPreview -> {
                        Column(Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp)) {
                            Text("LIVE PREVIEW", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 7.dp))
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { ctx -> WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = false
                                    webViewClient = WebViewClient()
                                    webChromeClient = WebChromeClient()
                                    setBackgroundColor(android.graphics.Color.rgb(11, 14, 23))
                                } },
                                update = { it.loadDataWithBaseURL(null, previewHtml, "text/html", "UTF-8", null) }
                            )
                        }
                    }
                    else -> {
                        Row(Modifier.fillMaxWidth().padding(top = 11.dp).background(Panel2, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Code, null, tint = Accent, modifier = Modifier.size(15.dp))
                            Text("  $fileName", color = MainText, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Spacer(Modifier.weight(1f)); Text("${source.lines().size} lines", color = Muted, fontSize = 10.sp)
                        }
                        Row(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF0B0E17), RoundedCornerShape(bottomStart = 10.dp, bottomEnd = 10.dp)).border(1.dp, Color(0xFF252B3B), RoundedCornerShape(bottomStart = 10.dp, bottomEnd = 10.dp))) {
                            Column(Modifier.width(37.dp).fillMaxHeight().verticalScroll(rememberScrollState()).padding(top = 12.dp), horizontalAlignment = Alignment.End) {
                                repeat(source.count { it == '\n' } + 1) { index -> Text("${index + 1}", color = Color(0xFF596176), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(end = 8.dp, bottom = 4.dp)) }
                            }
                            BasicTextField(
                                value = source,
                                onValueChange = { source = it },
                                modifier = Modifier.weight(1f).fillMaxHeight().padding(12.dp),
                                textStyle = TextStyle(color = Color(0xFFD7DDF0), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 20.sp),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent),
                                decorationBox = { inner -> Box { if (source.isEmpty()) Text("Start writing code...", color = Muted, fontFamily = FontFamily.Monospace); inner() } }
                            )
                        }
                    }
                }
                if (showConsole && !showFiles && !showPreview) {
                    Column(Modifier.fillMaxWidth().padding(top = 9.dp, bottom = 7.dp).background(Panel, RoundedCornerShape(12.dp)).padding(11.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, null, tint = Accent, modifier = Modifier.size(15.dp))
                            Text("  OUTPUT / CONSOLE", color = MainText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { console = "Console cleared." }, contentPadding = PaddingValues(0.dp)) { Text("CLEAR", color = Muted, fontSize = 9.sp) }
                        }
                        Text(console, color = Color(0xFFB9C5D9), fontFamily = FontFamily.Monospace, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                }
                Text("VANTA CODE 1.0  •  LOCAL WORKSPACE", color = Color(0xFF535B70), fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 5.dp))
            }
        }
    }
}


@Composable
private fun ActionChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, primary: Boolean = false, action: () -> Unit) {
    Surface(onClick = action, color = if (primary) Accent.copy(alpha = .20f) else Panel, shape = RoundedCornerShape(9.dp), border = BorderStroke(1.dp, if (primary) Accent.copy(alpha = .65f) else Color(0xFF272D40))) {
        Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (primary) Accent else Muted, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp)); Text(label, color = MainText, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
    }
}

private fun runJavaScript(code: String): String {
    val output = StringBuilder()
    val cx = JsContext.enter()
    return try {
        cx.optimizationLevel = -1
        val scope = cx.initStandardObjects()
        val writer = object : BaseFunction() {
            override fun call(cx: JsContext, scope: Scriptable, thisObj: Scriptable, args: Array<out Any>): Any {
                output.append(args.joinToString(" ") { JsContext.toString(it) }).append('\n')
                return JsContext.getUndefinedValue()
            }
        }
        ScriptableObject.putProperty(scope, "print", writer)
        val consoleObject = cx.newObject(scope)
        ScriptableObject.putProperty(consoleObject, "log", writer)
        ScriptableObject.putProperty(consoleObject, "warn", writer)
        ScriptableObject.putProperty(consoleObject, "error", writer)
        ScriptableObject.putProperty(scope, "console", consoleObject)
        val result = cx.evaluateString(scope, code, "VANTA-editor", 1, null)
        if (result !== JsContext.getUndefinedValue() && result != org.mozilla.javascript.Undefined.instance) {
            output.append("=> ").append(JsContext.toString(result)).append('\n')
        }
        if (output.isEmpty()) "Execution completed successfully. No output." else output.toString().trimEnd()
    } catch (e: Exception) {
        "JavaScript error: ${e.message ?: e.javaClass.simpleName}"
    } finally {
        JsContext.exit()
    }
}
